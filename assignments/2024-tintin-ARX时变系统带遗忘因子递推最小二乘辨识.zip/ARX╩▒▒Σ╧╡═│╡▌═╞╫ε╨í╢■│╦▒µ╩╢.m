clc
clear
close all

% 数据长度
N = 300;

% 定义系统 ARX 模型的阶数
na = 2; % AR 部分的阶数
nb = 2; % X 部分的阶数

% 定义时变系统参数
a1 = -1.5*ones(1, N) + 0.4*(1./(1+exp(-((1:N)-N/4)*0.05)));
a2 = 0.5*ones(1, N) - 0.1*(1./(1+exp(-((1:N)-N/3)*0.05)));
% a2 = 0.5*ones(1, N);
b1 = 1*ones(1, N) - 0.27*(1./(1+exp(-((1:N)-N/4)*0.05)));
b2 = 0.3*ones(1, N) + 0.1*(1./(1+exp(-((1:N)-N/3)*0.05)));
% b2 = 0.1*ones(1, N);

% 定义输入信号
u = 5*sin((1:N))';

% 系统初始化
y = zeros(N, 1);
y_h = zeros(na, 1);
u_h = zeros(nb, 1);
phi = zeros(na + nb ,N);
v = 0.01 * randn(N, 1); % 高斯白噪声


% RLS算法初始化
lambda = 0.95; % 遗忘因子
theta_hat = zeros(na + nb, N); % 参数估计初始化
P = 100000 * eye(na + nb); % 协方差矩阵初始化

% 仿真 ARX 时变系统
for i = 1:N
    % 更新系统状态
    if i > na
        y_h = [y(i-1); y_h(1:end-1)];
    end
    if i > nb
        u_h = [u(i-1); u_h(1:end-1)];
    end
    
    % 计算当前时刻的系统输出
    y(i) = -[a1(i), a2(i)] * y_h + [b1(i), b2(i)] * u_h + v(i);
    
    % 估计 ARX 模型参数
    phi(:, i) = [-y_h; u_h];
    if i > min(na,nb)
        K = P * phi(:, i) / (lambda + phi(:, i)' * P * phi(:, i)); % 增益
        theta_hat(:, i) = theta_hat(:, i-1) + K * (y(i) - phi(:, i)' * theta_hat(:, i-1)); % 参数更新
        P = (P - K * phi(:, i)' * P) / lambda; % 协方差矩阵更新   
    end
end

% 绘图
figure;
subplot(3, 1, 1);
plot(1:N, y);
hold on;
plot(1:N, v);
xlabel('时间');
ylabel('输出/噪声');
title('系统输出与噪声');
legend('系统输出', '噪声');
grid on;

subplot(3, 1, 2);
plot(1:N, a1, 'b-', 'LineWidth', 1.5);
hold on;
plot(1:N, a2, 'b--', 'LineWidth', 1.5);
hold on;
plot(1:N, b1, 'r-', 'LineWidth', 1.5);
hold on;
plot(1:N, b2, 'r--', 'LineWidth', 1.5);
xlabel('时间');
ylabel('参数值');
title('时变系统参数');
legend('a1', 'a2', 'b1', 'b2');
grid on;

subplot(3, 1, 3);
plot(1:N, theta_hat(1, :), 'b-', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_hat(2, :), 'b--', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_hat(3, :), 'r-', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_hat(4, :), 'r--', 'LineWidth', 1.5);
xlabel('时间');
ylabel('参数值');
title('时变系统辨识参数');
legend('a1', 'a2', 'b1', 'b2');
grid on;
