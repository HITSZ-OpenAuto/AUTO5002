% 定义模型系数
A = [1, -0.3, 0.5]; % AR部分
B = [0.5, 0.3]; % 外部输入部分

% 生成外部输入u(t)
N = 100;         % 仿真步数
u = ones(N, 1); % 单位阶跃信号


% 生成ARMA噪声
AR = [1, -0.5, 0.3];
MA = [1, 0.2, 0.5];
v = 0.01 * randn(N, 1);
e = zeros(N, 1);
for k = 3:N
    e(k) = - AR(2)*e(k-1) - AR(3)*e(k-2) + v(k) + MA(2)*v(k-1) + MA(3)*v(k-2);
end

% 仿真系统
y = zeros(N, 1);
for k = 3:N
    y(k) = - A(2)*y(k-1) - A(3)*y(k-2) + B(1)*u(k-1) + B(2)*u(k-2) + e(k);
end

% 绘制输出
plot(y,'b');
title('ARARMAX系统输出');
xlabel('时间');
ylabel('输出');
