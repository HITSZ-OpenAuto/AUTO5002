clc
clear
close all

% 数据长度
N = 500;

% 定义系统 ARARX 模型的阶数
na = 2; % AR 部分的阶数
nb = 2; % X 部分的阶数
nc = 2; % AR 部分的阶数

% 定义模型系数
A = [-0.5, 0.2]; % AR部分
B = [0.5, 0.2]; % X输入部分
C = [0.2, -0.1]; % AR部分

% 定义输入信号
u = idinput(N);

% 系统初始化
y = zeros(N, 1);
w = zeros(N, 1);
y_h = zeros(na, 1);
u_h = zeros(nb, 1);
w_h = zeros(nc, 1);
% y_h = [-0.5; 0.2];
% u_h = [0.5; 0.2];
% w_h = [0.5; 0.3];
phi_s = zeros(na + nb, N);
phi_n = zeros(nc, N);
phi = zeros(na + nb + nc, N);
v = 0.01 * randn(N, 1); % 标准正态分布白噪声
w_hat = zeros(N, 1);

% RLS算法初始化
lambda = 1; % 遗忘因子
theta_s = zeros(na + nb, N); % 参数估计初始化
theta_n = zeros(nc, N); 
theta_hat = [theta_s; theta_n];
P = 100 * eye(na + nb + nc); % 协方差矩阵初始化

for i = 1:N
    % 更新系统状态
    if i > na
        y_h = [y(i-1); y_h(1:end-1)];
    end
    if i > nb
        u_h = [u(i-1); u_h(1:end-1)];
    end
    
    if i > 2
        % 计算当前时刻的系统输出
        w(i) = - C(1)*w(i-1) - C(2)*w(i-2) + v(i);
        y(i) = - A(2)*y(i-2) - A(1)*y(i-1) + B(1)*u(i-1) + B(2)*u(i-2) + w(i); 
        
        w_h = [w_hat(i-1); w_h(1:end-1)];
        phi_n(:, i) = -w_h;
        phi_s(:, i) = [-y_h; u_h];
        phi(:, i) = [phi_s(:, i); phi_n(:, i)];
        L = P * phi(:, i) / (lambda + phi(:, i)' * P * phi(:, i));
        theta_hat(:, i) = theta_hat(:, i-1) + L * (y(i) - phi(:, i)' * theta_hat(:, i-1));
        theta_s(:, i) = theta_hat(1:na+nb, i);
        theta_n(:, i) = theta_hat(na+nb+1:na+nb+nc, i);
        P = (P - L * phi(:, i)' * P) / lambda;
        w_hat(i) = y(i) - phi_s(:, i)' * theta_s(:, i); 
        
    end
    
end

% 绘制输出
plot(1:N, theta_s(1, :), 'b-', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_s(2, :), 'b--', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_s(3, :), 'r-', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_s(4, :), 'r--', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_n(1, :), 'g-', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_n(2, :), 'g--', 'LineWidth', 1.5);
xlabel('时间');
ylabel('参数值');
title('ARARX系统辨识参数');
legend('a1', 'a2', 'b1', 'b2', 'c1', 'c2');
grid on;
