clc
clear
close all

% 数据长度
N = 500;

% 定义系统 ARARX 模型的阶数
na = 2; % AR 部分的阶数
nb = 2; % X 部分的阶数
nc = 2; % AR 部分的阶数

% 定义模型系数
A = [-0.5, 0.2]; % AR部分
B = [0.5, 0.2]; % X输入部分
C = [0.2, -0.1]; % AR部分

% 定义输入信号
u = idinput(N);

% 系统初始化
y = zeros(N, 1);
w = zeros(N, 1);
y_f = zeros(N, 1);
u_f = zeros(N, 1);
phi_s = zeros(na + nb, N);
phi_f = zeros(na + nb, N);
phi_n = zeros(nc, N);
v = 0.01 * randn(N, 1); % 标准正态分布白噪声
w_hat = zeros(N, 1);

% RLS算法初始化
lambda_s = 1; % 遗忘因子
lambda_n = 1;
theta_s = zeros(na + nb, N); % 参数估计初始化
theta_n = zeros(nc, N); 
P_s = 100 * eye(na + nb); % 协方差矩阵初始化
P_n = 100 * eye(nc); 

for i = 3:N
    w(i) = - C(1)*w(i-1) - C(2)*w(i-2) + v(i);
    y(i) = - A(2)*y(i-2) - A(1)*y(i-1) + B(1)*u(i-1) + B(2)*u(i-2) + w(i); 

    phi_s(:, i) = [-y(i-1); -y(i-2); u(i-1); u(i-2)];
    
    phi_n(:, i) = [-w_hat(i-1); -w_hat(i-2)];

    L_n = P_n * phi_n(:, i) / (lambda_n + phi_n(:, i)' * P_n * phi_n(:, i));
    theta_n(:, i) = theta_n(:, i-1) + L_n * (y(i) - phi_n(:, i)' * theta_n(:, i-1) - phi_f(:, i)' * theta_s(:, i-1));
    P_n = (P_n - L_n * phi_n(:, i)' * P_n) / lambda_n;

    y_f(i) = y(i) + [y(i-1), y(i-2)] * theta_n(:, i);
    u_f(i) = u(i) + [u(i-1), u(i-2)] * theta_n(:, i);

    phi_f(:, i) = [-y_f(i-1); -y_f(i-2); u_f(i-1); u_f(i-2)];
    
    L_s = P_s * phi_f(:, i) / (lambda_s + phi_f(:, i)' * P_s * phi_f(:, i));
    theta_s(:, i) = theta_s(:, i-1) + L_s * (y_f(i) - phi_f(:, i)' * theta_s(:, i-1));
    P_s = (P_s - L_s * phi_f(:, i)' * P_s) / lambda_s;

    w_hat(i) = y(i) - phi_s(:, i)' * theta_s(:, i); 
    
end

% 绘制输出
plot(1:N, theta_s(1, :), 'b-', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_s(2, :), 'b--', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_s(3, :), 'r-', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_s(4, :), 'r--', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_n(1, :), 'g-', 'LineWidth', 1.5);
hold on;
plot(1:N, theta_n(2, :), 'g--', 'LineWidth', 1.5);
xlabel('时间');
ylabel('参数值');
title('ARARX系统辨识参数');
legend('a1', 'a2', 'b1', 'b2', 'c1', 'c2');
grid on;
