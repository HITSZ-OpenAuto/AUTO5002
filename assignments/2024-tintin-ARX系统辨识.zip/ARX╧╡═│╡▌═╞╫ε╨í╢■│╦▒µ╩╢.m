clear; clc; close all;
rng(0);

% 初始化参数
T = 100; % 数据点数量
u = randn(T, 1); % 输入数据
v = randn(T, 1) * 0.1; % 噪声
y = zeros(T, 1); % 系统输出
theta_true = [0.5,0.3,0.1];

% 系统输出数据的生成
for k = 3:T
    y(k) = (theta_true(1) * y(k-1) + theta_true(2) * u(k-1) + theta_true(3) * u(k-2) + v(k)); % 根据ARX模型计算
end

% RLS算法初始化
lambda = 0.99; % 遗忘因子
theta_hat = zeros(3, 1); % 参数估计初始化([theta_y, theta_u1, theta_u2])
P = 1000 * eye(3); % 协方差矩阵初始化

% 参数估计历史记录
theta_history = zeros(T, 3);

% 递推最小二乘算法
for t = 3:T
    phi = [y(t-1); u(t-1); u(t-2)]; % 回归向量
    K = P * phi / (lambda + phi' * P * phi); % 增益
    theta_hat = theta_hat + K * (y(t) - phi' * theta_hat); % 参数更新
    P = (P - K * phi' * P) / lambda; % 协方差矩阵更新   
    theta_history(t, :) = theta_hat'; % 存储参数估计
end

% 显示最终参数估计结果
disp('最终参数估计结果:');
disp(theta_hat);

% 绘制参数估计历史
figure;
plot(theta_history);
yline(theta_true(1), 'r--', 'DisplayName', 'True theta_y');
yline(theta_true(2), 'g--', 'DisplayName', 'True theta_u1');
yline(theta_true(3), 'b--', 'DisplayName', 'True theta_u2');
legend('theta_y', 'theta_u1', 'theta_u2');
xlabel('Time Step');
ylabel('Parameter Estimate');
title('RLS Parameter Estimation History');
